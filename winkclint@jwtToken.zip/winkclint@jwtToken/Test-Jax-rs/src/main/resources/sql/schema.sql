DROP TABLE IF EXISTS user;

CREATE TABLE user (id int primary key,
 userName VARCHAR(30) ,
 phNumber int,
 address VARCHAR(50));