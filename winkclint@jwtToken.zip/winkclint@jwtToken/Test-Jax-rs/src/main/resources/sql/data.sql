INSERT INTO user(id, userName, phNumber,address) VALUES (1, 'User1',1234567890, 'Bangalore');
INSERT INTO user(id, userName, phNumber,address) VALUES (2, 'User2',1234567890, 'Chennai');
INSERT INTO user(id, userName, phNumber,address) VALUES (3, 'User3',1234567890, 'Delhi');
