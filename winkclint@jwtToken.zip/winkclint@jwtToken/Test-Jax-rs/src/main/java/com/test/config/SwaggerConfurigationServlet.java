package com.test.config;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.config.SwaggerContextService;
import io.swagger.models.Swagger;
import io.swagger.models.auth.BasicAuthDefinition;

public class SwaggerConfurigationServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		BeanConfig beanConfig = new BeanConfig();
		beanConfig.setBasePath("/Test-Jax-rs/rest");
		beanConfig.setHost("localhost:8080");
		beanConfig.setTitle("Metlife-Jax-rs Poc's");
		beanConfig.setResourcePackage("com.test");
		beanConfig.setPrettyPrint(true);
		beanConfig.setScan(true);
		beanConfig.setSchemes(new String[] {"http"});
		beanConfig.setVersion("1.0v");
		
		Swagger swagger = new Swagger();
	    swagger.securityDefinition("basicAuth", new BasicAuthDefinition());
	    new SwaggerContextService().withServletConfig(config).updateSwagger(swagger);
		
	}

}
