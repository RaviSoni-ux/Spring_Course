package com.test.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class UserValidation {

	public static final long JWT_TOKEN_VALIDITY = 30 * 60 ; // sec
	public static final String SECRET_KEY = "hello";

	public String validateUser(String username, String password) {
		String token = null;

		if (username.equals("ravi")) {
			token = generateToken(username);
			System.out.println("token--->>>>>" + token);

		}
		return token;

	}

	public String generateToken(String username) {
		Map<String, Object> claims = new HashMap<>();
		claims.put("role", "ADMIN");
		System.out.println("claims--->>> " + claims + "username--->>> " + username);
		return doGenerateToken(claims, username);
	}

	private String doGenerateToken(Map<String, Object> claims, String subject) {
		System.out.println("subject--->>" + subject);
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
				.signWith(SignatureAlgorithm.HS512, SECRET_KEY).compact();
	}

}
