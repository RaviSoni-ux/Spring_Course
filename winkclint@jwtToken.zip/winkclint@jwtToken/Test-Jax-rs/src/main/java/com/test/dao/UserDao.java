package com.test.dao;


import java.sql.SQLException;
import java.util.List;

import com.test.model.User;

public interface UserDao {

    List<User> getAll() throws SQLException;

    User get(final int id) throws SQLException;

    int create(final User user) throws SQLException;

    int delete(final int id) throws SQLException;

}