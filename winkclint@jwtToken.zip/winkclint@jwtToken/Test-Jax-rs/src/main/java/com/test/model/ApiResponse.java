package com.test.model;

public class ApiResponse {

	private String statusMessage;
	private String data;

	public ApiResponse() {
	}

	public ApiResponse(String statusMessage, String data) {
		this.statusMessage = statusMessage;
		this.data = data;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
