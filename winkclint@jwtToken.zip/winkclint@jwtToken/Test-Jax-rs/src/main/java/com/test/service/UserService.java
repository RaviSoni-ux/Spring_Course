package com.test.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.jvnet.hk2.annotations.Service;

import com.test.dao.UserDao;
import com.test.dao.UserRepo;
import com.test.model.User;

@Service
public class UserService implements UserDao {
	Logger log = Logger.getLogger(UserService.class.getName());

	private Connection connection;

	public UserService() {

		this.connection = UserRepo.getConnection();
	}

	@Override
	public List<User> getAll() throws SQLException {

		final String SELECT_ALL_USERS = "SELECT id, userName, phNumber, address FROM user";

		List<User> users = new ArrayList<>();
		log.info("inside getAllUsers service");
		try {

			PreparedStatement ps = connection.prepareStatement(SELECT_ALL_USERS);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				User user = new User(rs.getInt("id"), rs.getString("userName"), rs.getInt("phNumber"),
						rs.getString("address"));
				users.add(user);

			}
		} catch (SQLException e) {
// log
		}

		log.info(users.toString() + "users");
		return users;
	}

	@Override
	public User get(final int id) throws SQLException {

		final String SELECT_USER = "SELECT id, userName, phNumber, address FROM user WHERE id=?";
		log.info("inside get Individual user service");
		User user = null;
		try {
			PreparedStatement ps = connection.prepareStatement(SELECT_USER);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				user = new User(rs.getInt("id"), rs.getString("userName"), rs.getInt("phNumber"),
						rs.getString("address"));
			}
		} catch (SQLException e) {
// log
		}
		return user;
	}

	@Override
	public int create(final User user) throws SQLException {
		log.info(user.getUserName());
		final String CREATE_A_USER = "INSERT INTO user (id, userName, phNumber, address) VALUES (?, ?, ?, ?)";
		log.info("inside createUser service");
		try {

			PreparedStatement ps = connection.prepareStatement(CREATE_A_USER);

			ps.setInt(1, user.getId());
			ps.setString(2, user.getUserName());
			ps.setInt(3, user.getPhNumber());
			ps.setString(4, user.getAddress());
			log.info("setting values");
			int update = ps.executeUpdate();
			log.info(user.toString());
			connection.commit();
			log.info("success "+update);
			return update;

		} catch (SQLException e) {
			log.info("rollback");
			connection.rollback();
		}
		return 0;
	}

	@Override
	public int delete(final int id) throws SQLException {

		final String DELETE_A_USER = "DELETE FROM user WHERE id = ?";
		log.info("inside delete user service");
		try {
			PreparedStatement ps = connection.prepareStatement(DELETE_A_USER);
			ps.setInt(1, id);

			int update = ps.executeUpdate();

			connection.commit();

			return update;
		} catch (SQLException e) {
			connection.rollback();
		}
		return 0;
	}
}