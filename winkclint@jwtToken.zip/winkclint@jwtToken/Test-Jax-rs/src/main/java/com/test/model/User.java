package com.test.model;


public class User {
	
	
	private int id;
	private String userName;
	private int phNumber;
	private String address;
	
	public User() {
		
	}
	
	public User(int id, String userName, int phNumber, String address) {
		super();
		this.id = id;
		this.userName = userName;
		this.phNumber = phNumber;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(int phNumber) {
		this.phNumber = phNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", phNumber=" + phNumber + ", address=" + address + "]";
	}
	
}
