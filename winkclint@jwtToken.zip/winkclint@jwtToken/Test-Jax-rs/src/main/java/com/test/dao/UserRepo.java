package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class UserRepo {

	private static final String DB_DRIVER = "org.h2.Driver";
//private static final String DB_URL = "jdbc:h2:mem:testdb";
	private static final String DB_URL_NEW = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;"
			+ "INIT=RUNSCRIPT FROM 'classpath:/sql/schema.sql'" + "\\;RUNSCRIPT FROM 'classpath:/sql/data.sql'";
	private static final String DB_USERNAME = "sa";
	private static final String DB_PASSWORD = "";
	private static final Logger logger = LogManager.getLogger(UserRepo.class);

	public static Connection getConnection() {
		Connection connection = null;

		try {

			Class.forName(DB_DRIVER);
			connection = DriverManager.getConnection(DB_URL_NEW, DB_USERNAME, DB_PASSWORD);
			connection.setAutoCommit(false);
			logger.info("Connection Establish -->> "+connection);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("Connection ERROR");
			logger.info("Connection error");
		}
		return connection;
	}

}