package com.test;

import java.sql.SQLException;
import java.util.List;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.test.auth.Secured;
import com.test.model.ApiResponse;
import com.test.model.User;
import com.test.service.UserService;
import com.test.service.UserValidation;

import io.swagger.annotations.Api;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.annotations.Tag;

@Path("/hello/api")
@Api("/Hello Api")
@SwaggerDefinition(tags = { @Tag(name = "Hello Api", description = "Rest End Point for Hello Jax-Rs Poc") })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Singleton
public class UserController {

	/*
	 * @Inject private UserValidation userValidation;
	 */

	private UserService us;
	Logger log = LogManager.getLogger(UserController.class);

	public UserController() {
		this.us = new UserService();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello() {
		return "hello, GET mapping is working";
	}

	@POST
	@Path("/authenticate")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response authenticateUser(@FormParam("username") String username, @FormParam("password") String password) {
		log.info("username..>>>" +username);
		log.info("password..>>>" +password);
		System.out.println("usernam >."+username +"psw>>> "+password );
		UserValidation userValidation = new UserValidation();
		String token = userValidation.validateUser(username, password);
		if (token != null) {
			return Response.ok(new ApiResponse("token Generated successfully", token)).build();
		}
		return Response.ok(new ApiResponse("token not Generated", "Failed")).build();
	}

	@GET
	@Secured
	@Path("/users")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUsers(@HeaderParam("Authorization") String token) throws SQLException {
		log.info("Inside getAllUsers Controller");
		return us.getAll();
	}

	@GET
    @Secured
	@Path("users/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUser(@PathParam("id") int id,@HeaderParam("Authorization") String token) throws SQLException {
		log.info("Inside getUser Controller");

		User user = us.get(id);
		if (user == null) {
			return Response.status(Status.BAD_REQUEST.getStatusCode()).entity(user).build();
		}
		return Response.status(200).entity(user).build();

	}

	@POST
	@Secured
	@Path("users/add")
	public Response addUser(User user,@HeaderParam("Authorization") String token) throws SQLException {
		log.info("Inside addUser Controller");

		if (us.create(user) == 0) {

			return Response.status(Response.Status.BAD_REQUEST).build();
		}
		return Response.ok(new ApiResponse("user created successfully", "user created")).build();

	}

	@DELETE
	@Secured
	@Path("users/delete/{id}")
	public Response deleteUser(@PathParam("id") int id,@HeaderParam("Authorization") String token) throws SQLException {
		log.info("Inside DeleteUser Controller");

		if (us.delete(id) == 0) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
		return Response.ok(new ApiResponse("user deleted successfully", "user deleted")).build();

	}

}