package com.test.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.test.JerseyTest;
import org.junit.Before;
import org.junit.Test;

import com.test.UserController;
import com.test.auth.AuthenticationFilter;
import com.test.auth.Secured;
import com.test.model.ApiResponse;
import com.test.model.User;

public class ResourceIntegrationTest extends JerseyTest {

	static String newToken;
	
	@Override
	protected Application configure() {
		return new ResourceConfig(UserController.class,AuthenticationFilter.class);
	}
	
	@Before
	public void generateToken() {
		Form form = new Form();
		form.param("username", "ravi");
		form.param("password", "123456");

		Response response = target("/hello/api/authenticate").request().post(Entity.form(form));
		ApiResponse content = response.readEntity(ApiResponse.class);
		System.out.println(content.getStatusMessage());
		newToken="Bearer "+content.getData();
	}

	@Test
	public void sayHelloTest() {
		Response response = target("/hello/api").request().get();
		String content = response.readEntity(String.class);
		assertEquals("hello, GET mapping is working", content);
	}

	@Test
	public void authenticateUserTest() {
		Form form = new Form();
		form.param("username", "ravi");
		form.param("password", "123456");

		Response response = target("/hello/api/authenticate").request().post(Entity.form(form));
		ApiResponse content = response.readEntity(ApiResponse.class);
		System.out.println(content.getStatusMessage());
		newToken="Bearer "+content.getData();
		System.out.println("Token in Test Class ---->>  " + content.getData());
		assertEquals("token Generated successfully", content.getStatusMessage());
	}

	@Test
	public void authenticateUserFailureTest() {
		Form form = new Form();
		form.param("username", "pawan");
		form.param("password", "123456");

		Response response = target("/hello/api/authenticate").request().post(Entity.form(form));
		ApiResponse content = response.readEntity(ApiResponse.class);
		System.out.println(content.getData());
		assertEquals("Failed", content.getData());
		assertThat(content.getData(), containsString("Failed"));
	}

	@Test
	@Secured
	public void userListSuccessTest() {
		Response response = target("/hello/api/users").request().header("Authorization", newToken).get();
		System.out.println("user test-->>>>>" + response.getStatus());
		assertEquals(Status.OK.getStatusCode(), response.getStatus());

	}
	
	@Test
	public void getUserByIdSuccessTest() {
		Response response = target("/hello/api/users/1").request().header("Authorization", newToken).get();
		assertEquals(Status.OK.getStatusCode(), response.getStatus());
	}
	
	@Test
	public void getUserByIdFailureTest() {
		Response response = target("/hello/api/users/10").request().header("Authorization", newToken).get();
		assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
	}
	
	@Test
	public void addUserSuccesTest() {
		System.out.println("new Token "+newToken);
		Response response=target("/hello/api/users/add").request().header("Authorization", newToken).post(Entity.json(new User(5,"TestUser5",1234567890,"Bangalore")));
		System.out.println("adduser "+response);
		ApiResponse content = response.readEntity(ApiResponse.class);
		assertEquals("user created successfully", content.getStatusMessage());
		assertEquals(Status.OK.getStatusCode(), response.getStatus());		  
		assertThat(content.getData(), containsString("user created"));
		 
	}
	
	@Test
	public void deleteStudentSuccessTest() {
		Response response=target("/hello/api/users/delete/3").request().header("Authorization", newToken).delete();
		System.out.println(response);
		ApiResponse content = response.readEntity(ApiResponse.class);
		System.out.println(content.getStatusMessage());
		assertEquals("user deleted successfully", content.getStatusMessage());
		assertEquals(Status.OK.getStatusCode(), response.getStatus());		  
		assertThat(content.getData(), containsString("user deleted"));
	}
	
	@Test
	public void deleteStudentFailureTest() {
		Response response=target("/hello/api/users/delete/10").request().header("Authorization", newToken).delete();
		System.out.println(response);
		assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());	  
	}
}